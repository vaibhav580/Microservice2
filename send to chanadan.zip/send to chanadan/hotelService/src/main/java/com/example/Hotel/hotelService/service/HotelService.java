package com.example.Hotel.hotelService.service;

import com.example.Hotel.hotelService.entity.Hotel;

import java.util.List;

public interface HotelService {
    List<Hotel> getallHotel();
    Hotel getHotelByHotelID(String HotelId);
    Hotel createHotle( Hotel hotel);
}
