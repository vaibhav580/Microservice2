package com.example.Hotel.hotelService.service.impl;

import com.example.Hotel.hotelService.entity.Hotel;
import com.example.Hotel.hotelService.exception.RunTimeHotelEXception;
import com.example.Hotel.hotelService.repository.HotelRepository;
import com.example.Hotel.hotelService.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service("abc1")
public class HotelServiceimpl implements HotelService {
    @Autowired
    private HotelRepository hotelRepository;
    @Override
    public List<Hotel> getallHotel() {
        return hotelRepository.findAll() ;
    }

    @Override
    public Hotel getHotelByHotelID(String HotelId) {
        return hotelRepository.findById(HotelId).orElseThrow(()-> new RunTimeHotelEXception("Reponse not Found"));
    }

    @Override
    public Hotel createHotle(Hotel hotel) {
        return hotelRepository.save(hotel);
    }
}
