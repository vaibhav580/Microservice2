package com.example.Hotel.hotelService.exception;

import com.example.Hotel.hotelService.exception.payload.ApiRespone;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(RunTimeHotelEXception.class)
    public ResponseEntity<ApiRespone> handleException(RunTimeHotelEXception e){
        String message=e.getMessage();
        ApiRespone respone= ApiRespone.builder().message(message).success(true).status(HttpStatus.NOT_FOUND).build();
        return new ResponseEntity<>(respone,HttpStatus.ACCEPTED);
    }
}
