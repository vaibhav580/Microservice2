package com.example.Hotel.hotelService.contrller;

import com.example.Hotel.hotelService.entity.Hotel;
import com.example.Hotel.hotelService.service.HotelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/hotel")
public class HotleController {

    private HotelService hotelService;
     public HotleController(@Qualifier("abc2")HotelService hotelService){
         this.hotelService=hotelService;
     }

    @PostMapping
    public Hotel createAllHotel(@RequestBody Hotel hotel){
        return  hotelService.createHotle(hotel);

    }

    @GetMapping
    public List<Hotel> getAllHotel(){
        return  hotelService.getallHotel();
    }

    @GetMapping("{hotelId}")
    public Hotel gethotelbyId(@PathVariable String hotelId){
        return  hotelService.getHotelByHotelID(hotelId);
    }
}
