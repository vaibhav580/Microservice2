package com.example.Hotel.hotelService.exception;

public class RunTimeHotelEXception extends RuntimeException {
    public RunTimeHotelEXception(String reponseNotFound) {
        super((reponseNotFound));
    }
    public RunTimeHotelEXception() {
        super(("not Found Resource"));
    }

}
