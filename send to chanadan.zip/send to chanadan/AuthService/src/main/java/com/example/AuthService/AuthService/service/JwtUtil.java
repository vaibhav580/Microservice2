package com.example.AuthService.AuthService.service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class JwtUtil {// generate Token
    private final String SECRET_KEY="ZJ8hNQdZ5iJKvVc9xwqf1YzUN6Qbh0WhT7iY+WDYy9qukMEY1k2aUo==";
    private final long EXPIRATION_TIME=1000*60*60;
    public String generateToken(Authentication auth){
        User user= (User) auth.getPrincipal();
        return Jwts.builder().setSubject(user.getUsername())
                .claim("roles",user.getAuthorities())
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis()+EXPIRATION_TIME))
                .signWith(SignatureAlgorithm.HS256,SECRET_KEY)
                .compact();
    }
}
