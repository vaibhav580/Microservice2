package com.example.ServerRegistry.ServerRegistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
