package com.example.Rating.ratingService.controller;

import com.example.Rating.ratingService.entities.Rating;
import com.example.Rating.ratingService.service.ratingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rating")
public class RatingController {

    @Autowired
    private ratingService ratingService;

    @GetMapping
    public List<Rating> getALlRating(){
        return ratingService.getAllRating();
    }

    @GetMapping("{ratingId}")
    public  Rating getRatingByRatingId(@PathVariable String ratingId ){
        return  ratingService.getRatingByRatingId(ratingId);
    }
    @GetMapping("/user/{userId}")
    public  List<Rating> getRatingByuserId(@PathVariable String userId ){
        return  ratingService.getRatingByuserId(userId);
    }

    @PostMapping
    public  Rating createRating(@RequestBody Rating rating){
        return ratingService.CrateRating(rating);
    }
}
