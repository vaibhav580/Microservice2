package com.example.Rating.ratingService.service;

import com.example.Rating.ratingService.entities.Rating;

import java.util.List;

public interface ratingService {
    List<Rating> getAllRating();
    Rating getRatingByRatingId(String ratingId);
    Rating CrateRating(Rating rating);
    List<Rating> getRatingByuserId(String userID);
}
