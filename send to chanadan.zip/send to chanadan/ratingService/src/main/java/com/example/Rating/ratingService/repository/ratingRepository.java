package com.example.Rating.ratingService.repository;

import com.example.Rating.ratingService.entities.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ratingRepository extends JpaRepository<Rating,String> {
    List<Rating> findByUserId(String userId);
}
