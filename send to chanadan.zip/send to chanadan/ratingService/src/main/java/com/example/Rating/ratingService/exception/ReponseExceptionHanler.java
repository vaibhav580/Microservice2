package com.example.Rating.ratingService.exception;

public class ReponseExceptionHanler extends RuntimeException {
    public ReponseExceptionHanler(String responseIsNotFound) {
        super(responseIsNotFound);

    }
    public  ReponseExceptionHanler (){
        super("Resource is not find ");
    }
}
