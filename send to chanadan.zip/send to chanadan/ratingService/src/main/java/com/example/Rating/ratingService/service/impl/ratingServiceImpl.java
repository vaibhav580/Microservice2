package com.example.Rating.ratingService.service.impl;

import com.example.Rating.ratingService.entities.Rating;
import com.example.Rating.ratingService.exception.ReponseExceptionHanler;
import com.example.Rating.ratingService.repository.ratingRepository;
import com.example.Rating.ratingService.service.ratingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ratingServiceImpl implements ratingService {

    @Autowired
    private ratingRepository ratingrepository;

    @Override
    public List<Rating> getAllRating() {
        return  ratingrepository.findAll();
    }

    @Override
    public Rating getRatingByRatingId(String ratingId) {
        return ratingrepository.findById(ratingId).orElseThrow(()->new ReponseExceptionHanler("Response is not found"));
    }

    @Override
    public Rating CrateRating(Rating rating) {
        return ratingrepository.save(rating);
    }

    @Override
    public List<Rating> getRatingByuserId(String userID) {
        return ratingrepository.findByUserId(userID);
    }
}
